import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-jobs',
  imports: [],
  templateUrl: './admin-jobs.html',
  styleUrl: './admin-jobs.scss',
})
export class AdminJobs {}
