import { Component } from '@angular/core';

@Component({
  selector: 'app-my-applications',
  imports: [],
  templateUrl: './my-applications.html',
  styleUrl: './my-applications.scss',
})
export class MyApplications {}
