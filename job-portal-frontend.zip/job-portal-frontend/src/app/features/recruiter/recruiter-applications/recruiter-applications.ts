import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter-applications',
  imports: [],
  templateUrl: './recruiter-applications.html',
  styleUrl: './recruiter-applications.scss',
})
export class RecruiterApplications {}
