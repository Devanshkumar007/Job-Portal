import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { JobService } from '../../../core/services/job';
import { ApplicationService } from '../../../core/services/application';
import { AuthService, Job } from '../../../core/services/auth';

@Component({
  selector: 'app-job-detail',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatDividerModule,
    MatSnackBarModule,
    MatDialogModule
  ],
  templateUrl: './job-detail.html',
  styleUrl: './job-detail.scss'
})
export class JobDetail implements OnInit {
  job: Job | null = null;
  isLoading = true;
  isApplying = false;
  hasApplied = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private jobService: JobService,
    private applicationService: ApplicationService,
    public authService: AuthService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.jobService.getJobById(Number(id)).subscribe({
        next: (job) => {
          this.job = job;
          this.isLoading = false;
        },
        error: () => {
          this.isLoading = false;
          this.snackBar.open('Job not found!', 'Close', { duration: 3000 });
          this.router.navigate(['/jobs']);
        }
      });
    }
  }

  applyForJob() {
    if (!this.job) return;

    const user = this.authService.getCurrentUser();
    if (!user) return;

    this.isApplying = true;

    const applicationData = {
      userId: user.id,
      jobId: this.job.id,
      applicantEmail: user.email,
      jobTitle: this.job.title,
      company: this.job.companyName,
      resumeUrl: '',
      resumePublicId: ''
    };

    this.applicationService.applyForJob(applicationData).subscribe({
      next: () => {
        this.isApplying = false;
        this.hasApplied = true;
        this.snackBar.open('Application submitted successfully!', 'Close', { duration: 3000 });
      },
      error: (err: any) => {
        this.isApplying = false;
        this.snackBar.open(err.error?.message || 'Failed to apply. Please try again.', 'Close', { duration: 3000 });
      }
    });
  }

  formatSalary(salary: number): string {
    return `₹${(salary / 100000).toFixed(1)} LPA`;
  }

  goBack() {
    this.router.navigate(['/jobs']);
  }
}