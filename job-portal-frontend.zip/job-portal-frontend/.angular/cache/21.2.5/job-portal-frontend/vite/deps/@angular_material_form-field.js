import {
  MatFormFieldModule
} from "./chunk-L5IHPMBJ.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-SANMGII4.js";
import "./chunk-2HXZ66QP.js";
import "./chunk-FHLU5S6O.js";
import "./chunk-GWBU7KI5.js";
import "./chunk-AIEYJCOW.js";
import "./chunk-EHJ2S7FG.js";
import "./chunk-CM63O2CZ.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-HUOI63FZ.js";
import "./chunk-YM5MELRY.js";
import "./chunk-M3OFDMGI.js";
import "./chunk-PLIDUPGX.js";
import "./chunk-QAQNFT6G.js";
import "./chunk-PRWBPG2R.js";
import "./chunk-TQ6VN6WI.js";
import "./chunk-HA3EBGBC.js";
import "./chunk-KUW5KNZA.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
